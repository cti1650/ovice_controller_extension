;((global) => {
    const ovice = global.oviceConnecter()
    // console.log('onClick actionLeave')
    ovice.leave()
})(window)
