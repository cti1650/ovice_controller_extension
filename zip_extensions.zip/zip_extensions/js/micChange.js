;((global) => {
    const ovice = global.oviceConnecter()
    // console.log('onClick mic')
    ovice.mic()
})(window)
